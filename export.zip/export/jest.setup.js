jest.setTimeout(30000);

require('chromedriver');
